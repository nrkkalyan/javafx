/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplescreens.controller;

import multiplescreens.ScreensController;

/**
 *
 * @author rnimmagadda
 */
public abstract class AbstractController {
    
    protected ScreensController screensControler;
//    
//    protected Stage parentStage;
//    
//    public void setParentStage(Stage stage){
//        parentStage = stage;
//    }
//
    public void setScreenController(ScreensController service){
        screensControler =service;
    }
}
