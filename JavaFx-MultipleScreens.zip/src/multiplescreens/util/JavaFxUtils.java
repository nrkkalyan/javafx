/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package multiplescreens.util;

import java.net.URL;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import multiplescreens.controller.AbstractController;

/**
 *
 * @author rnimmagadda
 */
public class JavaFxUtils {
    public static FXMLLoader getFxmlLoader(String fxmlFile) {
        URL resource = IoTools.getResourceUrl(fxmlFile);
        return new FXMLLoader(resource);
    }
    
    
}
